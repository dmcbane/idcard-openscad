This directory contains regression tests scripts to check whether the
library is working correctly.  If all the scripts run without
producing any output, then all the tests have passed.
